The main report is `pocs-rasmus-lovstad.pdf`.
To run the code, install packages from requirements.txt and open Jupyter Notebook.
